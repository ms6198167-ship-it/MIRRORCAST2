# Test plan for subsequent milestones

The current milestone is a UI + real Bonjour browse foundation. Add these automated tests as the corresponding production modules are introduced:

- State transitions: idle → browsing → discovered → paired → streaming → stopped.
- Capability negotiation rejects unknown protocol versions and unsupported codecs.
- Pairing rejects expired, replayed, malformed, and incorrect tokens.
- Transport rejects oversized frames, invalid sequence numbers, and malformed commands.
- Discovery tolerates duplicate service updates, permission denial, network changes, and browser failure.
- Broadcast cancellation immediately closes the media sender and clears session state.
- Integration: physical iPhone/iPad to each supported receiver; Wi-Fi loss/recovery; orientation change; microphone on/off.
- Performance: memory ceiling, sustained frame rate, thermal behavior, battery use, dropped frames, and end-to-end latency.

No test results are claimed: this environment does not include Xcode or physical iOS devices.
